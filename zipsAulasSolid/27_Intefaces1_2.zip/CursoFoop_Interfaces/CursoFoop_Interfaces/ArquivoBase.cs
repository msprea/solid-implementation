﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoFoop_Interfaces
{
    class ArquivoBase
    {
        public virtual void Nome()
        {
            Console.WriteLine("Definir nome arquivo");
        }
    }
}
