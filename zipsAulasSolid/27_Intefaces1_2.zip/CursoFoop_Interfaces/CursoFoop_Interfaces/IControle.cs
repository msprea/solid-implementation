﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoFoop_Interfaces
{
    interface IControle
    {
        void Desenha();
    }
}
