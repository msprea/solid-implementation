﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoFoop_Interfaces
{
    interface ITeste
    {
        void Pintar();
    }
}
