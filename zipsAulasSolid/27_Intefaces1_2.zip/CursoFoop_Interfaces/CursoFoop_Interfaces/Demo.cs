﻿using System;

namespace CursoFoop_Interfaces
{
    class Demo : IControle, ITeste
    {
        public void Desenha()
        {
            throw new NotImplementedException();
        }

        public void Pintar()
        {
            throw new NotImplementedException();
        }
    }
}
