﻿namespace CursoFoop_Interfaces
{
    interface IGravar
    {
        void GravarArquivo();
    }
}
