﻿using System;

namespace CursoFoop_Composicao1
{
    class Program
    {
        static void Main(string[] args)
        {
          Console.ReadLine();
        }
    }
}
