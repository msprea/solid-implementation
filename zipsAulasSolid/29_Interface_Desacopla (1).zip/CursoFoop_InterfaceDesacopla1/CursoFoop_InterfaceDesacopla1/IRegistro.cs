﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoFoop_InterfaceDesacopla1
{
    interface IRegistro
    {
        void RegistraInfo(string mensagem);
    }
}
