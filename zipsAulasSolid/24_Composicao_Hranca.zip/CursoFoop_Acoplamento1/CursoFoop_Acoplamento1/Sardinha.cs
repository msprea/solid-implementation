﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CursoFoop_Acoplamento1
{
    class Sardinha : Animal
    {
    }
}
