﻿namespace CursoFoop_Acoplamento1
{
    class Homem : Animal
    { } 
    
}
