﻿namespace CursoFoop_Acoplamento1
{
    class Gato : Animal
    {        

    }
}
