﻿using System;

namespace CursoFoop_Acoplamento1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Herança");
        }
    }
}
