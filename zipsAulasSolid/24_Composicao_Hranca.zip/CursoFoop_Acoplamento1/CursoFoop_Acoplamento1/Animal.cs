﻿namespace CursoFoop_Acoplamento1
{
    class Animal
    {
        public int Idade { get; set; }
        public void Comer() { }
        public void Dormir() { }
        public void Andar() { }
    }
}
