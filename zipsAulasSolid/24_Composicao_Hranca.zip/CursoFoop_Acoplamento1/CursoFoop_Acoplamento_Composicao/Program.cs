﻿using System;

namespace CursoFoop_Acoplamento_Composicao
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Composição");
        }
    }
}
