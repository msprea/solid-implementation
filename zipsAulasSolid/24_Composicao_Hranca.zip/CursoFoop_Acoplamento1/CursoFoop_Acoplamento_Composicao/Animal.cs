﻿namespace CursoFoop_Acoplamento_Composicao
{
    class Animal
    {
        public int Idade { get; set; }
        public void Comer() { }
        public void Dormir() { }
        
    }
}
