﻿namespace CursoFoop_Acoplamento_Composicao
{
    class Sardinha
    {
        Animal sardinha = new Animal();
        ComportamentoNadar nadar = new ComportamentoNadar();

    }
}
