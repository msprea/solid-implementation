﻿using System;
using System.Collections.Generic;

namespace Agregacao
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadLine();
        }
    }
}
